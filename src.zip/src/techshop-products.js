export const techProducts = [
  {
    imageURL: "/images/water.jpg",
    name: "Water Leak Senzor The D-Link",
    price: 14.99,
    quantity: 1,
  },

  {
    imageURL: "/images/motion.jpg",
    name: "Motion Sensor Guardline",
    price: 24.99,
    quantity: 1,
  },

  {
    imageURL: "/images/smoke.jpg",
    name: "Smoke Sensor X-Sense",
    price: 19.99,
    quantity: 1,
  },

  {
    imageURL: "/images/camera.jpg",
    name: "Wireless Camera Ctronics PTZ",
    price: 99.99,
    quantity: 1,
  },

  {
    imageURL: "/images/smartHub.jpg",
    name: "Smart Hub Echo Flex",
    price: 49.99,
    quantity: 1,
  },
];
